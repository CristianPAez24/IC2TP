#!/bin/python3
from pygal import Pie

# Create a chart
chart = Pie(title='Ejecución y los ingresos brutos de MCU')

# Add data to the chart
with open('mcu.csv') as f:
    data = f.read()
    lines = data.splitlines()
    #print(lines)

    for line in lines:
        tally = line.split(',')
        #print(tally)
        
        team = tally[0]
        mcu = tally[1]
        chart.add(team, int(mcu))  

# Display the chart
chart.render()
